''' init for account app'''
__author__ = 'liyang1'
